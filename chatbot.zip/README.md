# Chatbot SMTP Email Sender

A lightweight **AI-inspired chatbot** that sends emails through **Gmail SMTP** using natural language commands.  
This project demonstrates how to combine **Flask**, **basic NLP**, and **SMTP integration** to automate email sending.

---

## 🚀 Features
- Send emails using **simple text commands** (e.g., `Send email to alice@example.com subject: Hi body: Hello!`).
- Supports **attachments** (files will be added if paths are provided).
- Minimal **NLP parser** to extract recipient, subject, and body.
- Simple **web interface** built with Flask (textarea input).
- Environment variables for secure configuration (`.env`).

---

## 🛠️ Tech Stack
- **Python 3.9+**
- **Flask** (for the API and web UI)
- **SMTP (smtplib)** for sending emails
- **dotenv** for environment variables
- Basic **Regex NLP**

---

## 📂 Project Structure
```
chatbot-smtp/
├── app.py              # Flask app (API + frontend)
├── email_sender.py     # SMTP email sending logic
├── nlp.py              # Simple NLP command parser
├── templates/
│   └── index.html      # Web UI
├── requirements.txt    # Dependencies
├── .env.example        # Example env file
└── .gitignore
```

---

## ⚙️ Setup Instructions

### 1. Gmail Preparation
1. Enable **2-Step Verification** in your Google account.  
2. Create an **App Password** (Google Account → Security → App Passwords).  
3. Copy the generated 16-character app password.  

---

### 2. Clone & Install
```bash
git clone https://github.com/yourusername/chatbot-smtp.git
cd chatbot-smtp
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate
pip install -r requirements.txt
```

---

### 3. Configure `.env`
Create a `.env` file in the project root:
```env
SENDER_EMAIL=your_email@gmail.com
APP_PASSWORD=your_app_password_here
```

---

### 4. Run the App
```bash
python app.py
```
Open [http://127.0.0.1:5000/](http://127.0.0.1:5000/) in your browser.

---

## 📝 Example Commands
- `Send email to alice@example.com subject: Meeting body: Let's meet tomorrow.`
- `Send mail to bob@example.com saying Hello Bob, how are you?`

---

## 🌱 Future Improvements
- 🌍 **Arabic language support** for NLP.
- 💬 Interactive **chat UI** instead of textarea.
- 🔒 **PGP encryption** for secure attachments.
- 🤖 **Intent classification** (e.g., reply, forward, schedule emails).

---

## 📜 License
This project is open-source under the **MIT License**.
